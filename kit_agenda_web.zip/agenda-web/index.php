<?php
/* ════════════════════════════════════════════════════════
   index.php · Página principal (kit de rescate)
   Este archivo YA está completo: no tienes que cambiarlo.
   Por ahora solo confirma que tu evento se guardó.
   En P2-B y P4 aquí verás la lista de tus eventos.
   ════════════════════════════════════════════════════════ */

// registrar.php te manda aquí con ?ok=1 cuando guarda bien
$guardado = isset($_GET['ok']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TODO Paso 5 · Pega aquí el MISMO <link> de Google Fonts que en registrar.php -->
    <link href="css/estilos.css" rel="stylesheet">
    <title>Mis eventos · AgendaWeb</title>
</head>
<body>
<div class="card">
    <h1 class="card__title">Mis eventos</h1>

    <?php if ($guardado): ?>
        <div class="alert alert--ok" role="status">&#9989; Evento guardado correctamente.</div>
    <?php endif; ?>

    <p class="card__meta">Pronto verás aquí la lista de tus eventos (práctica P4).</p>
    <a href="registrar.php" class="btn-primary">+ Nuevo evento</a>
</div>
</body>
</html>
