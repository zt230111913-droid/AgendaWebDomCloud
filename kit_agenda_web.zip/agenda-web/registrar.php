<?php
/* ════════════════════════════════════════════════════════
   registrar.php · AgendaWeb (kit de rescate P2–P3)
   Formulario (P2) + procesamiento (P3) en un solo archivo.
   Cada TODO te dice en qué paso de la guía se completa.
   ════════════════════════════════════════════════════════ */

// Función de ayuda: limpia un texto antes de mostrarlo en la página.
// Evita que alguien "inyecte" HTML o JavaScript (ataque XSS).
// Ejemplo:  echo e($titulo);
function e(?string $valor): string
{
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

// TODO Paso 7 · Recibir y validar los datos del formulario


// TODO Paso 8 · Guardar en MySQL (solo si no hubo errores)


?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TODO Paso 5 · Pega aquí el <link> de Google Fonts de tu marca -->
    <link href="css/estilos.css" rel="stylesheet">
    <title>Nuevo evento · AgendaWeb</title>
</head>
<body>
<div class="card">
    <h1 class="card__title">Nuevo evento</h1>
    <p class="card__meta">AgendaWeb de <!-- TODO Paso 4 · escribe aquí tu nombre --></p>

    <!-- TODO Paso 7 · Aquí se mostrarán los mensajes de error -->

    <!-- TODO Paso 6 · Pega aquí tu <form> -->

    <p class="card__link"><a href="index.php">Ver mis eventos</a></p>
</div>
</body>
</html>
